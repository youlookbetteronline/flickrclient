package com.example.gav.taskmanager.features.newtask;

public interface InsertTaskListener {
    void onInsertTask();
}
