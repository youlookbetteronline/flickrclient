package com.example.gav.taskmanager.features.newtask;

public interface PriorityDialogListener {
    void onPriorityChosen(Priority priority);
}
