package com.example.gav.taskmanager.main;

public interface DeleteTaskListener {
    void onDeleteTask(int index);
}
