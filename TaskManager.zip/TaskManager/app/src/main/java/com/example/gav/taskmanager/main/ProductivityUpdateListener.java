package com.example.gav.taskmanager.main;

public interface ProductivityUpdateListener {
    void onProductivityUpdate(int value);
}
